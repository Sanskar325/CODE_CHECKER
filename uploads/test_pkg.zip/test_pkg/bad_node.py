# bad_node.py
import rclpy
from rclpy.node import Node

class BadNode(Node):
    def __init__(self):
        super().__init__('bad_node')
        # ERROR 1: Syntax error (missing closing parenthesis)
        self.pub = self.create_publisher(String, 'topic', 10 

        # ERROR 2: Infinite loop with no sleep (Safety Check)
        while True:
            print("Spamming CPU")
